

document.addEventListener('DOMContentLoaded',()=> {
    const courseTab = document.getElementById('courseTab');
    const reviewTab = document.getElementById('reviewTab');
    const courseContent = document.getElementById('courseContent');
    const reviewContent = document.getElementById('reviewContent');
  
    if(!courseTab || !courseContent||!reviewContent||!reviewTab){
      console.error('ce nest pas présent');
      return;
    }
    reviewContent.style.display='none';
    courseTab.addEventListener('click',() => {
      courseContent.style.display = 'block';
      reviewContent.style.display ='none';
      courseTab.classList.add('active');
      reviewTab.classList.remove('active');
    
    });
  
    const reviewForm = document.getElementById^('reviewForm');
    if(reviewForm){
      reviewForm.addEventListener('submit',(e)=> {
        e.preventDefault();
        const reviewText = document.getElementById('reviewText').Value;
        if(reviewText){
          const newReview = document.createElement('div');
          newReview.classList.add('review-item');
          newReview.textContent=`Review: ${reviewText}`;
          reviewContent.insertBefore(newReview,reviewForm);
          document.getElementById('reviewText').Value ='';
  
        }
  
      });
    } else {
      console.error('formulaire review nonn trouvable');
    }
    const ajoutbouton= document.querySelector('.ajout-chapitre');
    if(ajoutbouton){
      ajoutbouton.addEventListener('click',()=> {
        if(!courseContent){
          console.error('Erreur');
          return;
        }
        const chapitreNum = courseContent.children.length + 1;
        const newCourseItem = document.createElement('div');
        newCourseItem.className = 'course-item';
        newCourseItem.textContent = `chapite: ${chapitreNum}: Nouveau chapitre`;
        courseContent.appendChild(newCourseItem);
        alert('Le nouveau chapitre a été ajoutÉ')
      });
    }else{
      alert('le bouton ajout est introuvable')
    }
  
  
  
  })
//pour le telechargement des documents
  document.querySelectorAll(".upload").forEach((button) => {
    button.addEventListener('click', function() {
    const contenuUrl = this.getAttribute("data-file-url");

        if (!contenuUrl) {
            alert("Rien à télécharger.");
            return;}
        const télécharger = document.createElement("a");
        télécharger.href = contenuUrl;
        télécharger.download = contenuUrl.split("/").pop();
        télécharger.click();
    });
});
