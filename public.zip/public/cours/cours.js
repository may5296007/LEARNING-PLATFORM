const coursesContainer = document.getElementById("courses-container");
const searchInput = document.getElementById("search-input");
const searchBtn = document.getElementById("search-btn");
const sortSelect = document.getElementById("sort-select");
const gridViewBtn = document.getElementById("grid-view-btn");
const listViewBtn = document.getElementById("list-view-btn");
const courses = Array.from(coursesContainer.children); 


courses.forEach(course => {
    course.addEventListener("click", () => {
        const link = course.dataset.url;

        window.location.href = link;
    });
});

//trie des cours
function sortCourses(order) {
    const currentCourses = Array.from(coursesContainer.children).filter(el => el.classList.contains('course-card'));
    const sortedCourses = currentCourses.sort((a, b) => {
        const titleA = a.querySelector(".title").textContent.trim().toLowerCase().replace('supprimer', '').trim();
        const titleB = b.querySelector(".title").textContent.trim().toLowerCase().replace('supprimer', '').trim();
        if (order === "a-z") return titleA.localeCompare(titleB);
        if (order === "z-a") return titleB.localeCompare(titleA);
        return 0;
    });

    
    coursesContainer.innerHTML = ""; 

    
    sortedCourses.forEach(course => coursesContainer.appendChild(course));
}


// Fonction pour rechercher les cours
function searchCourses(query) {
    const lowerQuery = query.toLowerCase().trim();
    const filteredCourses = courses.filter(course => {
        const title = course.querySelector(".title")?.textContent.toLowerCase() || "";
        return title.includes(lowerQuery);
    });
    
    coursesContainer.innerHTML = "";
    
    filteredCourses.forEach(course => coursesContainer.appendChild(course));
}



sortSelect.addEventListener("change", (event) => {
    sortCourses(event.target.value);
});

// Recherche avec le bouton de recherche
searchBtn.addEventListener("click", () => {
    searchCourses(searchInput.value);
});

// Recherche instantanée avec l'input
searchInput.addEventListener("input", () => {
    searchCourses(searchInput.value);
});

//grille
gridViewBtn.addEventListener("click", () => {
    coursesContainer.classList.remove("list-view");
});

//liste
listViewBtn.addEventListener("click", () => {
    coursesContainer.classList.add("list-view");
});



// Suppression d'un cours
document.addEventListener('DOMContentLoaded', () => {
    
    coursesContainer.addEventListener('click', async (event) => {
        if (event.target.classList.contains('close-button')) {
            const courseCard = event.target.closest('.course-card'); 
            const courseId = courseCard.getAttribute('data-id');

            if (courseId) {
                
                if (confirm("Êtes-vous sûr de vouloir supprimer ce cours ?")) {
                    try {
                        
                        const response = await fetch(`/api/courses/${courseId}`, {
                            method: 'DELETE',
                        });

                        if (!response.ok) {
                            throw new Error("Erreur lors de la suppression du cours.");
                        }

                        const result = await response.json();
                        alert(result.message);


                        courseCard.remove();
                    } catch (error) {
                        console.error("Erreur :", error);
                        alert("Impossible de supprimer le cours.");
                    }
                }
            } else {
                alert("L'ID du cours est introuvable.");
            }
        }
    });
});



// Ajout d'un nouveau cours
document.addEventListener("DOMContentLoaded", () => {
    const createBouton = document.querySelector(".button.is-success");

    createBouton.addEventListener("click", async () => {
        const title = prompt("Entrez le titre du cours :");
        if (!title) {
            alert("Le titre est obligatoire.");
            return;
        }

        const description = prompt("Entrez la description du cours :");
        if (!description) {
            alert("La description est obligatoire.");
            return;
        }

        const admin_id = null;

        try {
            const response = await fetch('/api/courses', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ title, description, admin_id })
            });

            if (!response.ok) {
                throw new Error('Erreur lors de la création du cours.');
            }

            const result = await response.json();
            console.log(result);

            const nouveauCourse = document.createElement("div");
            nouveauCourse.className = "course-card";
            nouveauCourse.setAttribute("data-id", result.id); 
            nouveauCourse.innerHTML = `
                <div class="title">${title}
                    <button class="close-button">supprimer</button>
                </div>
                <div class="description">
                    <p>${description}</p>
                </div>
                <button class="button">En savoir plus</button>
            `;
            coursesContainer.appendChild(nouveauCourse);
        } catch (error) {
            console.error("Erreur :", error);
            alert("Impossible de créer le cours.");
        }
    });
});

document.addEventListener("DOMContentLoaded", () => {
    const coursesContainer = document.getElementById("courses-container");
    const modifBouton = document.querySelector(".button.is-warning");

    // Fonction pour la modification
    modifBouton.addEventListener("click", () => {
        const courseCards = document.querySelectorAll(".course-card");

        courseCards.forEach((card) => {

            if (!card.querySelector(".edit-form")) {
                

                const editForm = document.createElement("div");
                editForm.classList.add("edit-form");
                editForm.style.marginTop = "10px"; 
                editForm.innerHTML = `
                    <label>
                        Titre : 
                        <input type="text" class="input edit-title" value="${card.querySelector(".title").innerText}" />
                    </label>
                    <label>
                        Description : 
                        <textarea class="textarea edit-description">${card.querySelector(".description p").innerText}</textarea>
                    </label>
                    <button class="button is-primary save-btn">Sauvegarder</button>
                `;

                
                editForm.addEventListener("click", (event) => {
                    event.stopPropagation();
                });

                
                card.appendChild(editForm);
                const saveBouton = editForm.querySelector(".save-btn");
                saveBouton.addEventListener("click", (event) => {
                    event.stopPropagation();
                    
                    const newTitle = editForm.querySelector(".edit-title").value;
                    const newDescription = editForm.querySelector(".edit-description").value;

                    card.querySelector(".title").innerText = newTitle;
                    card.querySelector(".description p").innerText = newDescription;

                    editForm.remove();
                });
            }
        });
    });

    const courseCards = document.querySelectorAll(".course-card");
    courseCards.forEach((card) => {
        card.addEventListener("click", (event) => {
            
            if (!event.target.closest(".edit-form") && !event.target.closest(".button")) {
                const courseUrl = card.getAttribute("data-url");
                if (courseUrl) {
                    window.location.href = courseUrl;
                }
            }
        });
    });
});

//gerer les admin
document.addEventListener('DOMContentLoaded', () => {
    const userRole = localStorage.getItem('userRole'); 
  
    if (userRole === 'student') {
      
      const createButton = document.querySelector(".button.is-success");
      const modifyButton = document.querySelector(".button.is-warning");
      const deleteButtons = document.querySelectorAll(".close-button");
  
      if (createButton) createButton.style.display = 'none';
      if (modifyButton) modifyButton.style.display = 'none';
      deleteButtons.forEach(button => button.style.display = 'none');
    }
  });
  

