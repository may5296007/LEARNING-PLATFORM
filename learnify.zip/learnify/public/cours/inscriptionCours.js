document.addEventListener("DOMContentLoaded", function () {
    const form = document.getElementById("inscriptionform");

    if (form) {
        form.addEventListener("submit", async function (event) {
            event.preventDefault(); // Empêche la soumission par défaut du formulaire

            const students = {
                nom: document.getElementById("nom").value,
                prenom: document.getElementById("prenom").value,
                identifiant: document.getElementById("identifiant").value,
                email: document.getElementById("email").value,
                password: document.getElementById("password").value,
            };

            // Vérifie que tous les champs sont remplis
            if (!students.nom || !students.prenom || !students.identifiant || !students.email || !students.password) {
                alert("Veuillez remplir tous les champs.");
                return;
            }

            try {
                // Envoie une requête POST à l'API
                const response = await fetch('/api/inscriptionsCours', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify(students),
                });

                // Si la réponse est OK
                if (response.ok) {
                    const data = await response.json(); // Lit la réponse
                    alert(data.message || "Inscription réussie !");
                    ajouterCookies(students); // Sauvegarde les données dans les cookies
                    form.reset(); // Réinitialise le formulaire
                } else {
                    // Si la réponse a un statut autre que 200 ou 201
                    const errorData = await response.json();
                    alert(`Erreur : ${errorData.message || "Une erreur s'est produite."}`);
                }
            } catch (error) {
                // En cas d'erreur réseau ou autre
                console.error("Erreur lors de la requête :", error);
                alert("Erreur lors de l'inscription. Veuillez réessayer.");
            }
        });
    }
});

function ajouterCookies(students) {
    document.cookie = `nom=${students.nom}; path=/`;
    document.cookie = `prenom=${students.prenom}; path=/`;
    document.cookie = `email=${students.email}; path=/`;
}

