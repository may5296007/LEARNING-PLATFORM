document.getElementById("inscriptionform").addEventListener("submit", async function(event) {
  event.preventDefault();

  const users = {
      nom: document.getElementById("nom").value,
      prenom: document.getElementById("prenom").value,
      username: document.getElementById("username").value,
      email: document.getElementById("email").value,
      password: document.getElementById("password").value,
      role: document.getElementById("role").value
  };

  if (!users.nom || !users.prenom || !users.username || !users.email || !users.password || !users.role) {
      alert("Veuillez remplir tous les champs.");
      return;
  }

  try {
      const response = await fetch('/api/inscriptions', {
          method: 'POST',
          headers: {
              'Content-Type': 'application/json'
          },
          body: JSON.stringify(users)
      });

      if (response.ok) {
          alert("Inscription réussie !");
          ajouterCookies(users); // Sauvegarder dans les cookies
          document.getElementById("inscriptionform").reset();
      } else {
          const errorData = await response.json();
          console.error(errorData);
          alert(`Erreur : ${errorData.message}`);
      }
  } catch (error) {
      alert("Erreur lors de l'inscription. Veuillez réessayer.");
      console.error(error);
  }
});

function ajouterCookies(users) {
  document.cookie = `nom=${encodeURIComponent(users.nom)}; path=/;`;
  document.cookie = `prenom=${encodeURIComponent(users.prenom)}; path=/;`;
  document.cookie = `username=${encodeURIComponent(users.username)}; path=/;`;
  document.cookie = `email=${encodeURIComponent(users.email)}; path=/;`;
  document.cookie = `role=${encodeURIComponent(users.role)}; path=/;`;
  alert('Données sauvegardées dans les cookies.');
}
