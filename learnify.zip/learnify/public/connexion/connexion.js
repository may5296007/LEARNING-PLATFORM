document.getElementById("connecter").addEventListener("click", async function () {
    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;
  
    try {
      const response = await fetch('/api/connexion', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email, password }),
      });
  
      const result = await response.json();
  
      if (response.ok) {
        alert(result.message); 

           // pour stocker le le role de l'utilisateur
        localStorage.setItem('userRole', result.role);

        window.location.href = '/cours';
        
      } else {
        document.getElementById("error-message").style.display = 'block';
        document.getElementById("error-message").textContent = result.message;
        alert(result.message); 
      }
    } catch (error) {
      console.error("Erreur réseau:", error);
      alert("Erreur de connexion au serveur. Veuillez réessayer plus tard.");
    }
  });
  

  document.getElementById("deconnecter").addEventListener("click", async function () {
    const response = await fetch('/api/deconnexion', { method: 'POST' });
    const result = await response.json();

    if (response.ok) {
      alert(result.message);
      window.location.href = '/cours';  
    } else {
      alert('Erreur lors de la deconexxion');
    }
  })

